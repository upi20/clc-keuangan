<!-- MAIN CONTENT -->
<div id="content">

	<!-- row -->
	<div class="row">
		
		<!-- col -->
		<div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
			<h1 class="page-title txt-color-blueDark">
				<!-- PAGE HEADER -->
				<i class="fa-fw fa fa-table"></i> 
				
				<?= $title ?>
			</h1>
		</div>
		<!-- end col -->
		
	</div>
	<!-- end row -->
	
	<!--
		The ID "widget-grid" will start to initialize all widgets below 
		You do not need to use widgets if you dont want to. Simply remove 
		the <section></section> and you can use wells or panels instead 
		-->
	
	<!-- widget grid -->
	<section id="widget-grid" class="">
	
		<!-- row -->
		<div class="row">
			
			<!-- NEW WIDGET START -->
			<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				
				<!-- Widget ID (each widget will need unique ID)-->
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
						<div class="well well-sm bg-color-blue txt-color-white text-center">
							<h5>Total Cabang</h5>
							<h3>100</h3>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
						<div class="well well-sm bg-color-teal txt-color-white text-center">
							<h5>Total Cabang belum RAB</h5>
							<h3>10</h3>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
						<div class="well well-sm bg-color-red txt-color-white text-center">
							<h5>Total Cabang udah RAB</h5>
							<h3>5</h3>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
						<div class="well well-sm bg-color-green txt-color-white text-center">
							<h5>Total Saldo Cabang</h5>
							<h3>35</h3>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
						<div class="well well-sm bg-color-darken txt-color-white text-center">
							<h5>Total Pemasukan Cabang</h5>
							<h3>49</h3>
						</div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
						<div class="well well-sm bg-color-blue txt-color-white text-center">
							<h5>Total Pengeluaran Cabang</h5>
							<h3>100</h3>
						</div>
					</div>
				</div>
				<!-- end widget -->
	
			</article>
			<!-- WIDGET END -->
			
		</div>
	
		<!-- end row -->
	
		<!-- row -->
	
		<div class="row">
	
			<!-- a blank row to get started -->
			<div class="col-sm-12">
				<!-- your contents here -->
			</div>
				
		</div>
	
		<!-- end row -->
	
	</section>
	<!-- end widget grid -->

</div>
<!-- END MAIN CONTENT -->