$(() =>
{
	// initialize responsive datatable
	$.initBasicTable('#dt_basic')
	const $table 	= $('#dt_basic').DataTable()
	$table.columns( 0 )
    .order( 'asc' )
    .draw()
})